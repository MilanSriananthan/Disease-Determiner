from Userlogin import UserLogin
import os
class PastHealth(UserLogin):
  '''
  This object contains the medical history of the user

  Attributes
  ----------
  pastSymptoms: list
    User's list of past Symptoms
  pastDiseases: list
    User's list of past Diseases
  pastAllergies: list
    User's list of past Allergies

  Methods
  -------
  addSymptoms(newSymptoms:str):void
    Adds new allergies to the attibute and their .txt file
  addDisease(newDiseases:str):void
    Adds new Diseases to the attibute and their .txt file
  addAllergy(newAllergies:str):void
    Adds new allergies to the attibute and their .txt file
  '''
  def __init__(self, username: str, password: str, pastSymptoms: list, pastDiseases: list, pastAllergies: list):
    '''
    Constuctor to build a Health object

    Parameters
    ----------
    pastSymptoms: list
      User's list of past sypmtoms
    pastDiseases: list
      User's list of past diseases
    pastAllergies: list
      User's list of past allergies

    '''
    super().__init__(username, password)
    self.pastSymptoms = pastSymptoms
    self.pastDiseases = pastDiseases
    self.pastAllergies = pastAllergies

  def addSymptoms(self, newSymptoms: str):
    '''
    User is able to add symptoms to their list

    Parameters
    ----------
    newSymptoms : str
      user can input the symptoms they want to add
    
    returns
    -------
    None
    '''
    completefile = os.path.join(self.username, "Symptoms.txt")
    f_output = open(completefile, 'a')
    f_output.write('Past Symptoms:')
    mySymptoms = newSymptoms.split(',')
    for i in range(len(mySymptoms)):
      self.pastSymptoms.append(mySymptoms[i]) 
      f_output.write('\n' + mySymptoms[i])

  def addDiseases(self, newDiseases: str):
    '''
    User is able to add diseases to their list

    Parameters
    ----------
    newDiseases : str
      user can input the diseases they want to add
    
    returns
    -------
    None
    '''
    completefile = os.path.join(self.username, "Diseases.txt")
    f_output = open(completefile, 'a')
    f_output.write('Past Diseases:')
    myDiseases = newDiseases.split(',')
    for i in range(len(myDiseases)):
      self.pastDiseases.append(myDiseases[i]) 
      f_output.write('\n' + myDiseases[i])

  def addAllergies(self, newAllergies: str):
    '''
    User is able to add allergies to their list

    Parameters
    ----------
    newAllergies : str
      user can input the allergies they want to add
    
    returns
    -------
    None
    '''
    completefile = os.path.join(self.username, "Allergies.txt")
    f_output = open(completefile, 'a')
    f_output.write('Past Allergies:')
    myAllergies = newAllergies.split(',')
    for i in range(len(myAllergies)):
      self.pastAllergies.append(myAllergies[i]) 
      f_output.write('\n' + myAllergies[i])
    
  def __str__(self):
    '''
    Default output string of the class

    Parameters
    ----------
    None
    
    returns
    -------
    None
    '''
    return self.username + "\n" + str(self.pastSymptoms) + '\n' + str(self.pastDiseases) + '\n' + str(self.pastAllergies)
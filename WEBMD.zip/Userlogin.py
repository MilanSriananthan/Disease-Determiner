import os
import Accounts
class UserLogin():
  '''
  This object is the user login information and checker

  Attributes
  ----------
  username: str
    The username for the user
  password : str
    The password the user has chosen
  
  Methods
  -------
  checkPassword():void
    Determines if the passowrd is longer than 8 character and contain a int
  existingUsername(nlist:list):void
    Determines if the username is already existing
  correctPassword():void
    Determine of the given password is corresponding for that username
  '''
  def __init__(self, username : str, password : str):
    '''
    Constructor used to build the UserLogin object

    Parameters
    ----------
    username : str
      User's username to login
    passwork : str
      User's password to login
    
    '''
    self.username = username
    self.password = password
    
  
  def checkPassword(self):
    '''
    Determines if the passowrd is longer than 8 character and contain a int

    Parameters
    ----------
    None
    
    returns
    -------
    bool
    '''
    if len(self.password) >= 8 and any(char.isdigit() for char in self.password):
      return True
    else:
      return False

  def existingUsername(self, nlist):
    '''
    Determines if the username is already existing

    Parameters
    ----------
    nlist: list
      the list used in order to search for the username
    
    returns
    -------
    bool
    '''
    x = True
    while x == True:
      if type(self.username) == int:     
        if self.username >1000 and self.username < len(nlist) + 1000:
          listPosition = (Accounts.binary_search(nlist,self.username))
          listinfo = str(nlist[listPosition])
          listinfo = listinfo.replace(' ', '')
          self.username = listinfo[4:]
          return True
        else:
          self.username = "defaultUsername"
      else:
        if os.path.exists(self.username):
          return True
        else:
          return False
    
    
    
  
  def correctPassword(self):
    '''
    Determine of the given password is corresponding for that username

    Parameters
    ----------
    None
    
    returns
    -------
    bool
    '''
    completefile = os.path.join(self.username, "personalInformation.txt")
    userFile = open(completefile, 'r')
    myFile = userFile.readline()
    userFile.close()
    if self.password == myFile[0:-1]:
      return True
    else:
      return False


  def __str__(self):
    '''
    Default string output for the user

    Parameters
    ----------
    None
    
    returns
    -------
    str
    '''
    return '{} - {}'.format(self.username, self.password)
from Userlogin import UserLogin
import os
class Disease(UserLogin):
  '''
  This object is the disease determiner section

  Attributes
  ----------
  numberOfDays: int
    Number of days user had the Disease
  symptoms : list
    List of symptoms that the user experinced

  Methods
  -------
  addCurrentSymptoms(currentSymptoms:str):void
    Adds the new current symptoms to the attibute and their .txt file
  determiner(self):void
    Determines the disease based on symptoms and write it to a file
  linkage(self):void
    provides the link for the users disease
   
  '''
  def __init__(self, username: str, password: str, numberOfDays : int, symptoms : list):
    '''
    Constuctor to build the type of disease

    Parameters
    ----------
    numberOfDays: int
      Number of days user had the Disease
    symptoms : list
      List of symptoms that the user experinced

    '''
    super().__init__(username, password)
    self.numberOfDays = numberOfDays
    self.symptoms = symptoms

  def addCurrrentSymptoms(self, currentSymptoms: str):
    '''
    User is able to add current symptoms to the program

    Parameters
    ----------
    currentSymptoms : str
      user can input the current symptoms they want to add
    
    returns
    -------
    None
    '''
    myCurrentSymptoms = currentSymptoms.split(',')
    for i in range(len(myCurrentSymptoms)):
      self.symptoms.append(myCurrentSymptoms[i]) 

    
  def determiner(self):
    '''
    Determines a disease and then writes it to the account file

    Parameters
    ----------
    None
    
    returns
    -------
    None
    '''
    with open('Diseases.txt', 'r') as document:
      answer = {}
      for line in document:
        if line.strip(): 
            key, value = line.split(':', 1)  
            answer[key] = value.split()  
    possibilites = [] 
    secPossibilites = []
    for key,value in answer.items():
      if value == self.symptoms:
        print("A direct match has been provided with your symptoms: " + key)
        correctDis = input("Enter 1 if you feel the match is accurate")
        if correctDis == '1':
          self.addDisease = key
          completefile = os.path.join(self.username, "Diseases.txt")
          f_output = open(completefile, 'a')
          f_output.write("\n" + key)
          f_output.close()
          break
      elif self.symptoms[0] in value and self.symptoms[1] in value :
        possibilites.append(key)
      elif self.symptoms[0] in value and self.symptoms[2] in value :
        possibilites.append(key)
      elif self.symptoms[1] in value and self.symptoms[2] in value :
        possibilites.append(key)
      elif self.symptoms[0] in value :
        secPossibilites.append(key)
      elif self.symptoms[1] in value :
        secPossibilites.append(key)
      elif self.symptoms[2] in value :
        secPossibilites.append(key) 
    if len(possibilites)> 0:
      print('Here are the following disease(s) that have matched atleast two of your symptoms: ' + str(possibilites))
      rightDis = input("Enter the position of the disease in the list that you feel is correct: ")
      self.addDisease = possibilites[int(rightDis) - 1]
      completefile = os.path.join(self.username, "Diseases.txt")
      f_output = open(completefile, 'a')
      f_output.write("\n" + self.addDisease)
      f_output.close()
    elif len(secPossibilites) > 0:
      print('Here are the following disease(s) that have matched only one of your symptoms: ' + str(secPossibilites))
      rightDis = input("Enter the position of the disease in the list that you feel is correct: ")
      self.addDisease = secPossibilites[int(rightDis) - 1]
      completefile = os.path.join(self.username, "Diseases.txt")
      f_output = open(completefile, 'a')
      f_output.write("\n" + self.addDisease)
      f_output.close()    

    
        
    return ''

  
  def linkage(self):
    '''
    Provides the link for the users disease

    Parameters
    ----------
    None
    
    returns
    -------
    None
    '''
    with open('DiseasesLinks.txt', 'r') as document:
      answer = {}
      for line in document:
        if line.strip(): 
            key, value = line.split(':', 1)  
            answer[key] = value.split()
    print('Here is the helpful like with information for your chosen disease:')
    print(answer[self.addDisease])
    return ''
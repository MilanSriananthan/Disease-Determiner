import names
import random
nlist = []
def createAccounts():
  '''
  Create a list of first and last names and writes it to a file
  
  Parameters
  ----------
  None

  Returns
  -------
  None
  '''
  f_output = open('accounts.txt', 'w')
  for i in range(1000,9999,1):
    userAccount = str(i) + " " + names.get_full_name()
    global nlist
    nlist.append(userAccount)
  f_output.write(userAccount + '\n')
  return 
  

def bubbleSort(nlist):
  '''
  Performs a bubble sort on a desired list
  
  Parameters
  ----------
  nlist: list
    The desired list to sort

  Returns
  -------
  None
  '''
  for passnum in range(len(nlist)-1,0,-1):
    for i in range(passnum):
      if nlist[i]>nlist[i+1]:
          temp = nlist[i]
          nlist[i] = nlist[i+1]
          nlist[i+1] = temp
  f_output = open('filename.txt', 'w')
  for i in range(len(nlist)):
    f_output.write(nlist[i] + "\n")
  f_output.close()
  return
  
def insertionSort(nlist): 
  '''
  Performs a insertion sort on a desired list
  
  Parameters
  ----------
  nlist: list
    The desired list to sort

  Returns
  -------
  None
  '''
  for i in range(1, len(nlist)): 
    key = nlist[i] 
    j = i-1
    while j >=0 and key < nlist[j] : 
      nlist[j+1] = nlist[j] 
      j -= 1
      nlist[j+1] = key 

def linearSearch(nlist,target):
  '''
  Performs a linear search on a specific target in a desired list
  
  Parameters
  ----------
  nlist: list
    The desired list to sort
  target: str or int
    the value that needs to be found

  Returns
  -------
  int
    the position of the value in the list
  '''
  found = False
  position = 0
  while position < len(nlist) and not found:
    if str(target) in nlist[position]:
      found = True
    position = position + 1
  if found == False:
    position = 0

    return position - 1

def binary_search(nlist, target):
  '''
  Performs a binary search on a specific target in a desired list
  
  Parameters
  ----------
  nlist: list
    The desired list to sort
  target: str or int
    the value that needs to be found

  Returns
  -------
  int
    the position of the value in the list
  '''
  lower = 0
  upper = len(nlist)
  while lower < upper:   
    x = lower + (upper - lower) // 2
    val = nlist[x]
    if str(target) in val:
      return nlist.index(val)
    elif target > int(val[0:4]):
      if lower == x:  
        return -1        
      lower = x
    elif target < int(val[0:4]):
      upper = x
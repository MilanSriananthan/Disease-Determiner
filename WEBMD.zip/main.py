from Userlogin import UserLogin
from UserInformtation import UserInformation
from PastHealth import PastHealth
from DiseaseDeterminer import Disease
import Accounts
import random

symptoms = ['Fever', 'Headache', 'Rashes', 'White Patches', 'Stiffness', 'Fatigue', 'Muscle Cramps', 'Choking', 'Body Ache', 'Poor Skin', 'Loss of Appetite', 'Nausea', 'Chest Pain', 'Diarrhea', 'Dehydration', 'Difficult Breathing', 'Swollen Glands', 'Numbness', 'Chilliness', 'Abdominal Pain', 'Swelling', 'Excessive Peeing', 'Excessive Sweating', 'Prolonged Sore', 'Mole/Wart', 'Poor Cognitive Function', 'Hair Loss']
#Accounts.createAccounts()
with open('accounts.txt', 'r') as f:
  nlist = [line.strip() for line in f]


print('Enter your new username if it is your first time to offline WEBMD')
user_1 = UserLogin(input('Enter Username or Account #: '), "")
try:
    user_1.username = int(user_1.username)
except ValueError:
    print('')

if user_1.existingUsername(nlist) == False:
  print("Hello, " + user_1.username + " you are creating a new account please \nstart by entering you credentials.")
  user_1 = UserInformation(user_1.username, input('Enter Password: '), input('Enter First Name: '), input('Enter Last Name: '), input('Enter Phone Number: '), input('Enter Birthday: '), input('Enter gender: '), input('Enter Email address: '))
  
  if len(user_1.password) <= 8 or not any(char.isdigit() for char in user_1.password):
    print("Your password doesn't meet the following requirements")
    print("- Longer then 8 Characters")
    print('- Must contain atleast one number')
    user_1.password = input("Enter New Password: ")
  user_1.userFile(nlist)
  user_1 = PastHealth(user_1.username, user_1.password, [], [],[])
  print("Please enter any past medical information you recall (seperate by commas.")
  user_1.addSymptoms(input('Enter any past symptoms you had: '))
  user_1.addDiseases(input('Enter any past diseases you had: '))
  user_1.addAllergies(input('Enter any past allergies you had: '))
else:
  correct = False
  while correct == False:
    user_1.password = input('Enter Password: ')
    if user_1.correctPassword() == False:
      print('wrong password, try again')
    else:
      correct = True
again = True
while again == True:
  user_1 = Disease(user_1.username, user_1.password,3, [] )
  for i in range(len(symptoms)):
    print(str(i + 1) + ". " + symptoms[i])
  user_1.addCurrrentSymptoms(input("Enter the numbers of three of the symptoms you have?: "))
  print(Disease.determiner(user_1))
  print(Disease.linkage(user_1))
  keepgoing = input('Type anything and then enter to try the disease determiner again or just enter to exit the program: ' )
  if keepgoing == '':
    again = False



#int is the reperesentation for a number, however it may not have a decimal point in it
#float is used for a number but this time it must include a decimal point and if the given value doesnt include one then the float will just assign a .0 at the end
#double type variable is a 64-bit floating data type
#string is used to store text and must always be elcosed with '' or ""
#bool is where the only two values are True and False
#list is multiple values in [] that are seperated by commas
#tuples are similar to list but are immutable and are enclosed in {}
#dictionaries have a key and value and multiple of these



'''
Strings - they are immutable and the original string cannot be changed the length of the string depends on the computer
Int - again vary depending on computer and are numbers without the decimal point
float - 64bit number, that contains a decimal point
Boolean only can be two values with the first letter being capitalized
Array- the dimmension of the array is immuatable after it is created arrays can be changed by storing the value in a new variable

'''
'''
#Sorting and Searching not needed any more
random.shuffle(nlist)
print('Start timing')
Accounts.bubbleSort(nlist)
print(nlist)
print("shuffle")

random.shuffle(nlist)
print('Time Next')
Accounts.insertionSort(nlist)
print(nlist)

print('shuffling')
random.shuffle(nlist)

print('Time Next\n\n\n\n\n\n')

nlist.sort()
print(nlist)
print('stop timer')
print(Accounts.linearSearch(nlist,
'Milan Sriananthan'))
print(Accounts.binary_search(nlist,9987))
'''
from Userlogin import UserLogin
import os
import Accounts
class UserInformation(UserLogin):
  '''
  This object contains the basic personal information of the User

  Attributes
  ----------
  Username : str
    The username of the user
  password : str
    The password for the user
  firstName : String
    User's first Name
  lastName : String
    User's last name
  phoneNumber : String
    User's phone number
  dateBirth : Date
    User's date of birth
  gender : String
    User's Gender
  email : String
    User's email address

  Methods
  -------
  userFile(nlist: list):void
    Inputs the user information into their own .txt file for later use

'''
  def __init__(self, username : str, password : str, firstName: str, lastName : str, phoneNumber : int, dateBirth : str, gender : str, email : str):
    '''
    Constuctor to build the UserInformation object

    Parameters
    ----------
    firstName : String
      User's first Name
    lastName : String
      User's last name
    phoneNumber : String
      User's phone number
    dateBirth : Date
      User's date of birth
    gender : String
      User's Gender
    email : String
      User's email address

    '''
    super().__init__(username, password)
    self.firstName = firstName
    self.lastName = lastName
    self.phoneNumber = phoneNumber
    self.dateBirth = dateBirth
    self.gender = gender
    self.email = email
  
  def userFile(self,nlist: list):
    '''
    Able to add the user information to a file

    Parameters
    ----------
    nlist : list
      the list used to write username to the file
    
    returns
    -------
    None
    '''
    num_lines = len(nlist)
    accountsfile = open('accounts.txt', 'a')
    accountsfile.write("\n" + str(num_lines+1000)+' ' + self.username)
    accountNumber = (Accounts.linearSearch(nlist,'Milan Sriananthan') + 1000)

    accountinfo = [self.password, self.firstName, self.lastName, self.phoneNumber, self.dateBirth, self.gender, self.email, accountNumber]
    
    os.makedirs(self.username)
    
    writeToFolder = os.path.join(self.username, 'personalInformation.txt')
    f_new = open(writeToFolder, 'w')
    for i in range(len(accountinfo)):
      f_new.write(str(accountinfo[i]) + '\n')
    f_new.close()
    
    

  def __str__(self):
    '''
    Default output string for the class

    Parameters
    ----------
    None

    returns
    ------
    String
    '''
    return '{} - {}'.format(self.firstName, self.lastName)